#pragma once
#include<fstream>
#include<iostream>
#include<vector>
using namespace std;


#include"MC.h"
#include"people.h"
#include"player.h"
#include"viewer.h"



class BTC
{
public:
	BTC();
	void start();
	void update();
	void end();
private:
	int chapter;
	bool isOver;
	MC mc;
	player plr[4];
	vector<viewer> vr;
};

BTC::BTC()
{
	isOver = false;
	int i;
	cout << "so khan gia?=";
	cin >> i;
	for (i; i > 0; i--)
	{
		vr.push_back(viewer());
	}
}

void start()
{
	while (!isOver)
	{

	}
}


