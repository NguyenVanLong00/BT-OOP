
#include<iostream>
#include"MC.h"

int main()
{
	MC x;
	return 0;
}